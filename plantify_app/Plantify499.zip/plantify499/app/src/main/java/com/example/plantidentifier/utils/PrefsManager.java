package com.example.plantidentifier.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;


import java.lang.reflect.Type;
import java.util.ArrayList;

public class PrefsManager {
    private static SharedPreferences getPrefs(Context context)
    {
        return context.getSharedPreferences("plantify",Context.MODE_PRIVATE);
    }
    //save the items locally
    public static void saveList(Context context, ArrayList<String> list)
    {
        SharedPreferences.Editor editor = PrefsManager.getPrefs(context).edit();
        Gson gson = new Gson();
        ArrayList<String> textList = new ArrayList<String>(list);
        String jsonText = gson.toJson(textList);
        editor.putString("list",jsonText);
        editor.apply();
    }
    //get the items saved locally
    public static ArrayList<String> getList(Context context)
    {
        ArrayList<String> list = new ArrayList<>();
        Gson gson = new Gson();
        String json = PrefsManager.getPrefs(context).getString("list", null);
        Type type = new TypeToken<ArrayList<String>>() {}.getType();
        if (type != null && json != null)
        {
            list.addAll(gson.fromJson(json, type));
        }
        return list;
    }
}
