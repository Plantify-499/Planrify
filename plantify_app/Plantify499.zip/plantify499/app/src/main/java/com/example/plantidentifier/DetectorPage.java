package com.example.plantidentifier;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import com.example.plantidentifier.databinding.ActivityDetectorPageBinding;
import com.example.plantidentifier.utils.PrefsManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import java.io.IOException;
import java.util.ArrayList;
public class DetectorPage extends AppCompatActivity {
    private String plantFinalName = "";
    boolean alreadyExists = false;
    Bitmap bitmap;
    private ActivityDetectorPageBinding binding;
    @Override
    public void onBackPressed() {
        return;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDetectorPageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.myPlantsTap:
                        startActivity(new Intent(getApplicationContext(), HomePage.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.detectorTap:
                        return true;
                }
                return false;
            }
        });
        binding.uploadImageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                startActivityForResult(intent, 150);
            }
        });
        checkAndGetPermissions();
        binding.detectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                plantFinalName = "Mango";
                binding.resultTextView.setText(plantFinalName+":\nThe young mango plants require 9-12 litre/day/plant water for better growth.");
                binding.addPlantBtn.setVisibility(View.VISIBLE);
            }
        });
        binding.cameraBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(camera, 200);
            }
        });
        binding.addPlantBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alreadyExists = false;
                ArrayList<String> savedList = new ArrayList<>();
                savedList.addAll(PrefsManager.getList(DetectorPage.this));
                savedList.add(plantFinalName);
                PrefsManager.saveList(DetectorPage.this, savedList);
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 150) {
            binding.imageView2.setImageURI(data.getData());
            Uri uri = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
            } catch (IOException e) {
            }
        } else if (requestCode == 200 && resultCode == Activity.RESULT_OK) {
            bitmap = (Bitmap) data.getExtras().get("data");
            binding.imageView2.setImageBitmap(bitmap);
        }
    }
    public void checkAndGetPermissions() {
        if (ContextCompat.checkSelfPermission(DetectorPage.this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(DetectorPage.this, new String[]{Manifest.permission.CAMERA}, 100);
            if (ContextCompat.checkSelfPermission(DetectorPage.this, Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_DENIED) {
                Toast.makeText(DetectorPage.this, "Camera access granted", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(DetectorPage.this, "Camera access granted", Toast.LENGTH_LONG).show();
        }
    }
}