package com.example.plantidentifier;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import com.ekn.gruzer.gaugelibrary.Range;
import com.example.plantidentifier.adapters.PlantsListAdapter;
import com.example.plantidentifier.databinding.ActivityPlantDetailsBinding;

public class PlantDetailsActivity extends AppCompatActivity {

    private ActivityPlantDetailsBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPlantDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        //get the clicked item name and display it in textview
        binding.plantName.setText(getIntent().getStringExtra("name"));

        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        Range range = new Range();
        range.setColor(Color.parseColor("#089516"));
        range.setFrom(0.0);
        range.setTo(100.0);

        binding.gaugeSoil.setMinValue(0.0);
        binding.gaugeSoil.setMaxValue(100.0);
        binding.gaugeSoil.setValue(50.0);
        binding.gaugeSoil.addRange(range);

        binding.gaugeHumidity.setMinValue(0.0);
        binding.gaugeHumidity.setMaxValue(100.0);
        binding.gaugeHumidity.setValue(70.0);
        binding.gaugeHumidity.addRange(range);


        binding.gaugeLight.setMinValue(0.0);
        binding.gaugeLight.setMaxValue(100.0);
        binding.gaugeLight.setValue(30.0);
        binding.gaugeLight.addRange(range);

        binding.gaugeTemp.setMinValue(0.0);
        binding.gaugeTemp.setMaxValue(100.0);
        binding.gaugeTemp.setValue(90.0);
        binding.gaugeTemp.addRange(range);

        binding.gaugeWater.setMinValue(0.0);
        binding.gaugeWater.setMaxValue(100.0);
        binding.gaugeWater.setValue(10.0);
        binding.gaugeWater.addRange(range);

    }
}