package com.example.plantidentifier;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import com.example.plantidentifier.adapters.PlantsListAdapter;
import com.example.plantidentifier.databinding.ActivityHomePageBinding;
import com.example.plantidentifier.interfaces.ItemClickListener;
import com.example.plantidentifier.utils.PrefsManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import java.util.ArrayList;
import java.util.Locale;

public class HomePage extends AppCompatActivity {

    private ActivityHomePageBinding binding;
    private PlantsListAdapter adapter;
    private ArrayList<String> list = new ArrayList<>();
    private ArrayList<String> searchedList = new ArrayList<>();

    @Override
    public void onBackPressed() {
        return;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHomePageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.ivLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                finishAffinity();
            }
        });
        binding.ivClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.edSearch.setText("");}
        });
        binding.edSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {}
            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                if (s.length() == 0) {
                    adapter.updateList(list);
                } else {
                    searchedList.clear();
                    for (int i = 0; i < list.size(); i++) {
                        if (list.get(i).toLowerCase(Locale.ROOT).contains(s.toString().toLowerCase(Locale.ROOT))) {
                            searchedList.add(list.get(i));
                        }
                    }
                    if (!searchedList.isEmpty())
                        adapter.updateList(searchedList);
                    else
                        adapter.updateList(list);
                }
            }
        });

        initRV();
        binding.bottomNavigationView.setSelectedItemId(R.id.myPlantsTap);
        //--------- NAVIGATION BAR
        binding.bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {

                    case R.id.myPlantsTap:

                        return true;
                    case R.id.detectorTap:
                        startActivity(new Intent(getApplicationContext(), DetectorPage.class));
                        overridePendingTransition(0, 0);
                        return true;

                }

                return false;
            }
        });
    }

    private void initRV() {
        //get the items saved locally
        ArrayList<String> savedList = PrefsManager.getList(HomePage.this);
        list.addAll(savedList);
        adapter = new PlantsListAdapter(list, new ItemClickListener() {
            //open details of the clicked item
            @Override
            public void onClick(int position) {
                String name = "";
                if (searchedList.isEmpty()) {
                    name = list.get(position);
                } else {
                    name = searchedList.get(position);
                }
                startActivity(new Intent(HomePage.this, PlantDetailsActivity.class)
                        .putExtra("name", name));
            }
            //Delete the items in the list
            @Override
            public void onDelete(int position) {
                if (searchedList.isEmpty()) {
                    list.remove(position);
                } else {
                    for (int i = list.size() - 1 ; i > 0; i--) {
                        if (list.get(i).equals(searchedList.get(position))) {
                            list.remove(i);
                        }
                    }
                    searchedList.remove(position);
                }
                adapter.notifyItemRemoved(position);
                PrefsManager.saveList(HomePage.this, list);
            }
        });
        binding.rv.setLayoutManager(new LinearLayoutManager(this));
        binding.rv.setAdapter(adapter);
    }
}