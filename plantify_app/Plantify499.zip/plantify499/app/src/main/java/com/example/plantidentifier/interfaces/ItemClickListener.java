package com.example.plantidentifier.interfaces;

public interface ItemClickListener {

    void onClick(int position);
    void onDelete(int position);
}
